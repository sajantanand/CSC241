NAME:  Sajant Anand
CSC-241 Lab 2

Ordinary compiling method will suffice to compile this program (%cc lab1.c %./a.out).

My input file has 4000 lines of text.


