NAME:  Sajant Anand
CSC-241 Lab 3 

Program that creates a simple shell. Commands that exist in the directories specified by the PATH variable can be executed ( i.e. 'cd' does not work ).

Ordinary compiling method will suffice to compile this program (%cc lab3.c %./a.out).
