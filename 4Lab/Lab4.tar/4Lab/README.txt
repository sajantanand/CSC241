NAME:  Sajant Anand
CSC-241 Lab 4 

Implementation of the Sleeping Barbers problem using the EZIPC.h library. The program uses one barber and one cashier. The length of hair cuts and the time delay between arrival of customers is randomly generated and dependent on macros defined at the top of the source code file.

Ordinary compiling method will suffice to compile this program (%cc lab4.c %./a.out).
