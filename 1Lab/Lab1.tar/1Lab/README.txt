NAME:  Sajant Anand
CSC-241 Lab 1

Ordinary compiling method will suffice to compile this program (%cc lab1.c %./a.out).


