#include <stdio.h>

int main()
{
	//FILE * fp;
	//fp = fopen ( "lab5.txt", "w");
	int i = 1;
	/*
	while ( i < 101 )
	{	
		//fprintf ( fp, "This is line number %d!\n", i );
		int num = rand () % 26 + 65;
		putc ( num, fp );

		if ( i % 20 == 0 )
		{
			putc ( '\n', fp );
		}
	
		i++;
	}
	*/

	char test = '\0';	

	printf ( "%d\n", test );
	printf ( "after print\n" );
	return 0;
}
