NAME:  Sajant Anand
CSC-241 Lab 5 

Implementation of Conway's Problem with adaptations. We read lines of 20 characters (simulate a card of length 20), replace all ** with #, and print out characters in 25 character lines. This is achieved through the use of a print process, a squash process ( which replaces consequtive ** with a # ), and reader process (the reader process is the main process).

Input file is provided as a command line arguement: ./a.out FILE_NAME	./a.out data_conway.txt

Ordinary compiling method will suffice to compile this program (%cc lab5.c %./a.out FILE_NAME).
